import hashlib
import json
import urllib.request
import ftplib
import os
from logging import getLogger
# noinspection PyPep8Naming
import keras.backend as k

from keras.engine.topology import Input
from keras.engine.training import Model
from keras.layers.convolutional import Conv2D, MaxPooling2D
from keras.layers import GlobalAveragePooling2D
from keras.layers.core import Activation, Dense, Flatten
from keras.layers.merge import Add
from keras.layers.normalization import BatchNormalization
from keras.losses import mean_squared_error
from keras.regularizers import l2
from keras import backend as K

from chess_zero.config import Config

logger = getLogger(__name__)


class ChessModel:
    def __init__(self, config: Config):
        self.config = config
        self.model = None  # type: Model
        self.digest = None

    def build(self):
        mc = self.config.model
        data = Input((2, 8, 8))  # [own(8x8), enemy(8x8)]

        x = self.conv2d_bn(data, 32, 3, strides=2, padding='valid')
        x = self.conv2d_bn(x, 32, 3, padding='valid')
        x = self.conv2d_bn(x, 64, 3)
        x = MaxPooling2D(3, strides=2)(x)
        x = self.conv2d_bn(x, 80, 1, padding='valid')
        x = self.conv2d_bn(x, 192, 3, padding='valid')
        x = MaxPooling2D(3, strides=2)(x)

        branch_0 = conv2d_bn(x, 96, 1)
        branch_1 = conv2d_bn(x, 48, 1)
        branch_1 = conv2d_bn(branch_1, 64, 5)
        branch_2 = conv2d_bn(x, 64, 1)
        branch_2 = conv2d_bn(branch_2, 96, 3)
        branch_2 = conv2d_bn(branch_2, 96, 3)
        branch_pool = AveragePooling2D(3, strides=1, padding='same')(x)
        branch_pool = conv2d_bn(branch_pool, 64, 1)
        branches = [branch_0, branch_1, branch_2, branch_pool]
        channel_axis = 1
        x = Concatenate(axis=channel_axis)(branches)

        for block_idx in range(1, 11):
            x = inception_resnet_block(x,
                                       scale=0.17,
                                       block_type='block35')

        branch_0 = conv2d_bn(x, 384, 3, strides=2, padding='valid')
        branch_1 = conv2d_bn(x, 256, 1)
        branch_1 = conv2d_bn(branch_1, 256, 3)
        branch_1 = conv2d_bn(branch_1, 384, 3, strides=2, padding='valid')
        branch_pool = MaxPooling2D(3, strides=2, padding='valid')(x)
        branches = [branch_0, branch_1, branch_pool]
        x = Concatenate(axis=channel_axis)(branches)

        for block_idx in range(1, 21):
            x = inception_resnet_block(x,
                                       scale=0.1,
                                       block_type='block17')

        branch_0 = conv2d_bn(x, 256, 1)
        branch_0 = conv2d_bn(branch_0, 384, 3, strides=2, padding='valid')
        branch_1 = conv2d_bn(x, 256, 1)
        branch_1 = conv2d_bn(branch_1, 288, 3, strides=2, padding='valid')
        branch_2 = conv2d_bn(x, 256, 1)
        branch_2 = conv2d_bn(branch_2, 288, 3)
        branch_2 = conv2d_bn(branch_2, 320, 3, strides=2, padding='valid')
        branch_pool = MaxPooling2D(3, strides=2, padding='valid')(x)
        branches = [branch_0, branch_1, branch_2, branch_pool]
        x = Concatenate(axis=channel_axis)(branches)

        for block_idx in range(1, 10):
            x = inception_resnet_block(x,
                                       scale=0.2,
                                       block_type='block8')

        x = inception_resnet_block(x,
                                   scale=1.,
                                   activation=None,
                                   block_type='block8')

        x = self.conv2d_bn(x, 1536, 1)

        res_out = x
        # for policy output
        x = GlobalAveragePooling2D()(x)
        policy_out = Dense(self.config.n_labels, activation="softmax", name="policy_out")(x)

        # for value output
        x = GlobalAveragePooling2D()(res_out)
        x = Dense(mc.value_fc_size, activation="relu")(x)
        value_out = Dense(1, activation="tanh", name="value_out")(x)

        self.model = Model(in_x, [policy_out, value_out], name="chess_model")

    def preprocess_input(x):
        x /= 255.
        x -= 0.5
        x *= 2.
        return x

    def conv2d_bn(self,
                  x,
                  filters,
                  kernel_size,
                  strides=1,
                  padding='same',
                  activation='relu',
                  use_bias=False,
                  data_format='channels_first'):
        
        x = Conv2D(filters,
                   kernel_size,
                   strides=strides,
                   padding=padding,
                   use_bias=use_bias,
                   data_format=data_format)(x)
        if not use_bias:
            bn_axis = 1
            x = BatchNormalization(axis=bn_axis, scale=False)(x)
        if activation is not None:
            x = Activation(activation)(x)
        return x

    def inception_resnet_block(self, x, scale, block_type, block_idx, activation='relu'):
        if block_type == 'block35':
            branch_0 = conv2d_bn(x, 32, 1)
            branch_1 = conv2d_bn(x, 32, 1)
            branch_1 = conv2d_bn(branch_1, 32, 3)
            branch_2 = conv2d_bn(x, 32, 1)
            branch_2 = conv2d_bn(branch_2, 48, 3)
            branch_2 = conv2d_bn(branch_2, 64, 3)
            branches = [branch_0, branch_1, branch_2]
        elif block_type == 'block17':
            branch_0 = conv2d_bn(x, 192, 1)
            branch_1 = conv2d_bn(x, 128, 1)
            branch_1 = conv2d_bn(branch_1, 160, [1, 7])
            branch_1 = conv2d_bn(branch_1, 192, [7, 1])
            branches = [branch_0, branch_1]
        elif block_type == 'block8':
            branch_0 = conv2d_bn(x, 192, 1)
            branch_1 = conv2d_bn(x, 192, 1)
            branch_1 = conv2d_bn(branch_1, 224, [1, 3])
            branch_1 = conv2d_bn(branch_1, 256, [3, 1])
            branches = [branch_0, branch_1]
        channel_axis = 1
        mixed = Concatenate(axis=channel_axis)(branches)
        up = conv2d_bn(mixed,
                       K.int_shape(x)[channel_axis],
                       1,
                       activation=None,
                       use_bias=True)

        x = Lambda(lambda inputs, scale: inputs[0] + inputs[1] * scale,
                   output_shape=K.int_shape(x)[1:],
                   arguments={'scale': scale})([x, up])
        if activation is not None:
            x = Activation(activation)(x)
        return x

    @staticmethod
    def fetch_digest(weight_path):
        if os.path.exists(weight_path):
            m = hashlib.sha256()
            with open(weight_path, "rb") as f:
                m.update(f.read())
            return m.hexdigest()

    def load(self, config_path, weight_path):
        mc = self.config.model
        resources = self.config.resource
        if mc.distributed and config_path == resources.model_best_config_path:
            try:
                logger.debug(f"loading model from server")
                ftp_connection = ftplib.FTP(resources.model_best_distributed_ftp_server,
                                            resources.model_best_distributed_ftp_user,
                                            resources.model_best_distributed_ftp_password)
                ftp_connection.cwd(resources.model_best_distributed_ftp_remote_path)
                ftp_connection.retrbinary("RETR model_best_config.json", open(config_path, 'wb').write)
                ftp_connection.retrbinary("RETR model_best_weight.h5", open(weight_path, 'wb').write)
                ftp_connection.quit()
            except:
                pass

        if os.path.exists(config_path) and os.path.exists(weight_path):
            logger.debug(f"loading model from {config_path}")
            with open(config_path, "rt") as f:
                self.model = Model.from_config(json.load(f))
            self.model.load_weights(weight_path)
            self.digest = self.fetch_digest(weight_path)
            logger.debug(f"loaded model digest = {self.digest}")
            return True
        else:
            logger.debug(f"model files does not exist at {config_path} and {weight_path}")
            return False

    def save(self, config_path, weight_path):
        logger.debug(f"save model to {config_path}")
        with open(config_path, "wt") as f:
            json.dump(self.model.get_config(), f)
            self.model.save_weights(weight_path)
        self.digest = self.fetch_digest(weight_path)
        logger.debug(f"saved model digest {self.digest}")

        mc = self.config.model
        resources = self.config.resource
        if mc.distributed and config_path == resources.model_best_config_path:
            try:
                logger.debug(f"saving model to server")
                ftp_connection = ftplib.FTP(resources.model_best_distributed_ftp_server,
                                            resources.model_best_distributed_ftp_user,
                                            resources.model_best_distributed_ftp_password)
                ftp_connection.cwd(resources.model_best_distributed_ftp_remote_path)
                fh = open(config_path, 'rb')
                ftp_connection.storbinary('STOR model_best_config.json', fh)
                fh.close()

                fh = open(weight_path, 'rb')
                ftp_connection.storbinary('STOR model_best_weight.h5', fh)
                fh.close()
                ftp_connection.quit()
            except:
                pass


def objective_function_for_policy(y_true, y_pred):
    # can use categorical_crossentropy??
    return k.sum(-y_true * k.log(y_pred + k.epsilon()), axis=-1)


def objective_function_for_value(y_true, y_pred):
    return mean_squared_error(y_true, y_pred)
